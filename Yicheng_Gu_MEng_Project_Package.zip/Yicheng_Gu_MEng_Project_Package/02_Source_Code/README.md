# Source-Code Versions

| File | Role in development |
|---|---|
| `impedance_control_v1.c` | Initial Cartesian impedance, force-bias calibration, Z-equilibrium adjustment, slow X scan, and joint-6 locking. |
| `impedance_control_v2.c` | Reduced stiffness, removed joint-6 locking, and introduced manual XY guidance and orientation following. |
| `impedance_control_v3.c` | Introduced direction-based XY velocity guidance, Z contact regulation, velocity damping, and task-force limits. |
| `impedance_control_v4.c` | Adjusted interaction thresholds, limits, direction parameters, and Z response. |
| `impedance_control_v5.c` | Increased XY command speed, reduced rotational resistance, and scaled Cartesian task torque at joint 6. |
| `impedance_control_v5.1.c` | Added buffered approximately 100 Hz logging, timestamped filenames, and Enter-based controlled termination. This version was used for the reported experiments. |

All files retain their historical `.c` extension but contain C++ code intended for compilation as part of the libfranka C++ examples. Versions v1-v5 are preserved unchanged from the original project archive. Comments in v5.1 were corrected for consistency with the implemented values without changing its control logic.
