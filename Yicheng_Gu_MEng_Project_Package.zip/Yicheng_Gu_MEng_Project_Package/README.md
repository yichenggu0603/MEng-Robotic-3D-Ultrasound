# Regular MEng Project Submission Package

**Student:** Yicheng Gu  
**Student ID:** 251495965  
**Supervisor:** Prof. Elvis Chen  
**Project title:** Human-Assisted Hybrid Interaction Control Toward Robotic 3D Ultrasound Acquisition  
**Date:** August 2026

## Package contents

- `01_Report/Final_Report.pdf`: final report in submission format.
- `01_Report/Final_Report.docx`: editable version of the final report.
- `02_Source_Code/impedance_control_v1.c` through `impedance_control_v5.c`: original controller-development versions.
- `02_Source_Code/impedance_control_v5.1.c`: final logged controller used for the reported experiments.
- `03_Experimental_Data/`: the 19 CSV logs listed in Appendix A of the report, grouped by experimental condition.
- `FILE_MANIFEST.csv`: file list, sizes, and SHA-256 checksums.

## Source-code note

The source files retain their historical `.c` filenames, but they contain C++ and were compiled as libfranka C++ examples. Versions v1-v5 are included unchanged to document the development history. Version v5.1 is the final logged controller used for the reported experiments. The reported experimental environment used Ubuntu 24.04.3 LTS, a 6.8.1-1035-realtime kernel, libfranka 0.13.6-1, and Eigen. The final controller was run as a standalone program rather than as a ROS 2 controller plugin.

## Experimental-data note

The dataset contains 19 trials collected on 30 July 2026:

- Pose 1: 3 stationary no-contact trials.
- Pose 2: 7 nominally stationary soft-surface contact trials.
- Pose 3: 3 manually guided no-contact trials.
- Pose 4: 2 combined guidance and soft-surface contact trials.
- Directional guidance: 4 manual-guidance trials (two backward and two forward).

The four Pose 2 steady-state windows used for the primary stationary analysis are documented in Appendix A of the report. Raw CSV samples are included without additional filtering. No ultrasound images or direct external-force-sensor measurements were collected in the reported experiments.

## Reproduction boundary

The package records the final controller, report, and raw logs used in the analysis. Exact binary reproduction may depend on the FR3 system-software version, compiler version, Eigen version, and local libfranka build configuration, which were not all recorded during the experiments.
